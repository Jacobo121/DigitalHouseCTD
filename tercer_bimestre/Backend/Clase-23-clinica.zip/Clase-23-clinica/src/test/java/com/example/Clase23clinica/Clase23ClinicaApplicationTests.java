package com.example.Clase23clinica;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Clase23ClinicaApplicationTests {

	@Test
	void contextLoads() {
	}

}
