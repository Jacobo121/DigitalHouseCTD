package com.example.Clase23clinica;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Clase23ClinicaApplication {

	public static void main(String[] args) {
		SpringApplication.run(Clase23ClinicaApplication.class, args);
	}

}
